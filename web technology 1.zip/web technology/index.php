<?php
session_start();
include('server.php'); // Include database connection

$error_message = "";
$success_message = "";

// Handle login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $_SESSION["username"] = $username;
        header("Location: final_all.html"); // Redirect to a new page after successful login
        exit();
    } else {
        $error_message = "Invalid username or password";
    }
}

// Handle signup
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['signup'])) {
    $username = $_POST['signup_username'];
    $email = $_POST['signup_email'];
    $password = $_POST['signup_password'];
    $confirm_password = $_POST['signup_confirm_password'];

    if ($password != $confirm_password) {
        $error_message = "Passwords do not match!";
    } else {
        $query = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";
        if ($conn->query($query) === TRUE) {
            $success_message = "Sign up successful! Now you can log in.";
        } else {
            $error_message = "Error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Career Guidance Login/Sign Up</title>
    <style>
        /* Your CSS styles go here */
    </style>
</head>
<body>
    <div class="container">
        <div class="background">
            <div class="welcome-text">
                <h1>Welcome<br>to<br>Career<br>Paths</h1>
            </div>
        </div>
        <div class="form-container">
            <div class="form-content">
                <div class="login-image">
                    <img src="https://cdn4.vectorstock.com/i/1000x1000/61/88/user-icon-human-person-symbol-avatar-login-sign-vector-28996188.jpg" alt="Career Guidance">
                </div>

                <!-- Login Form -->
                <form method="post" id="login-form">
                    <h2>Login</h2>
                    <input type="text" name="username" placeholder="Username" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <button type="submit" name="login">Login</button>
                    <?php if (!empty($error_message)) { echo "<p class='error-message'>$error_message</p>"; } ?>
                    <p class="toggle-form">Don't have an account? <span onclick="toggleForm()">Sign Up</span></p>
                </form>

                <!-- Signup Form -->
                <form method="post" id="signup-form" style="display: none;">
                    <h2>Sign Up</h2>
                    <input type="text" name="signup_username" placeholder="Username" required>
                    <input type="email" name="signup_email" placeholder="Email" required>
                    <input type="password" name="signup_password" placeholder="Password" required>
                    <input type="password" name="signup_confirm_password" placeholder="Confirm Password" required>
                    <button type="submit" name="signup">Sign Up</button>
                    <?php if (!empty($success_message)) { echo "<p class='success-message'>$success_message</p>"; } ?>
                    <p class="toggle-form">Already have an account? <span onclick="toggleForm()">Login</span></p>
                </form>
            </div>
        </div>
    </div>

    <script>
        function toggleForm() {
            const loginForm = document.getElementById('login-form');
            const signupForm = document.getElementById('signup-form');

            if (loginForm.style.display === 'none') {
                loginForm.style.display = 'block';
                signupForm.style.display = 'none';
            } else {
                loginForm.style.display = 'none';
                signupForm.style.display = 'block';
            }
        }
    </script>
</body>
</html>
