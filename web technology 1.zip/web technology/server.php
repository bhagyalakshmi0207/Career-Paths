<?php
// server.php

// Database configuration
$servername = "localhost";   // Database server, typically 'localhost' for local development
$username = "root";          // Database username
$password = "";              // Database password
$dbname = "career_paths";    // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
