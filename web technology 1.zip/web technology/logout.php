<?php
session_destroy();
header("location: minii.php");
?>